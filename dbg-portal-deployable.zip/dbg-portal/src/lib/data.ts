export const clients = [
  { id: 'c1', name: 'JNK Multi Services', email: 'contact@jnk.fr', catalog: 'Privé' },
  { id: 'c2', name: 'La Flèche Sous Bois', email: 'gerard@laflechesousbois.fr', catalog: 'Privé' },
  { id: 'c3', name: 'Karting La Roche', email: 'team@kartinglaroche.fr', catalog: 'Privé' }
];

export const orders = [
  { id: 'DBG-2026-001', client: 'JNK Multi Services', project: 'Signalétique camion', amount: '207,09 €', stage: 4, status: 'Production' },
  { id: 'DBG-2026-002', client: 'La Flèche Sous Bois', project: 'T-shirts événement', amount: '596,00 €', stage: 3, status: 'BAT' },
  { id: 'DBG-2026-003', client: 'Karting La Roche', project: 'Réassort hoodies équipe', amount: '1 180,00 €', stage: 1, status: 'Devis' }
];

export const uploads = [
  { id: 'u1', name: 'bat-flsousbois-v2.pdf', path: 'c2/DBG-2026-002/bat/bat-flsousbois-v2.pdf' },
  { id: 'u2', name: 'camion-prod.pdf', path: 'c1/DBG-2026-001/production/camion-prod.pdf' }
];

export const stages = ['Demande', 'Devis', 'Validation', 'BAT', 'Production', 'Expédition', 'Livré'];
