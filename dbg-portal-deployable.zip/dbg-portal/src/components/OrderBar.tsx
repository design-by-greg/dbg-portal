import { stages } from '@/lib/data';
export default function OrderBar({stage}:{stage:number}){
  return <div className="orderbar">{stages.map((s,i)=><div key={s} className={`stage ${i<=stage?'on':''}`}>{s}</div>)}</div>
}
