'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const nav = [
  ['/', 'Dashboard'],
  ['/orders', 'Commandes'],
  ['/clients', 'Clients'],
  ['/workflow', 'Devis & BAT'],
  ['/files', 'Fichiers'],
  ['/billing', 'Paiement'],
  ['/settings', 'Paramètres']
];

export default function AppShell({children}:{children:React.ReactNode}){
  const path = usePathname();
  return <div className="shell"><div className="grid"><aside className="sidebar"><div className="small muted">Design by Greg</div><h2 style={{marginTop:8}}>DBG Portal</h2><div className="small muted" style={{marginBottom:16}}>Version déployée</div><nav className="nav">{nav.map(([href,label]) => <Link key={href} href={href} className={path===href?'active':''}>{label}</Link>)}</nav></aside><main className="panel">{children}</main></div></div>
}
