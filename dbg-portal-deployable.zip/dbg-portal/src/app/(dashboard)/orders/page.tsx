import { orders } from '@/lib/data';
import OrderBar from '@/components/OrderBar';
import Link from 'next/link';
export default function Page(){return <div className="stack"><div className="row"><div><h1>Commandes</h1><div className="muted">Base déployable de suivi commandes</div></div><button className="btn dark">Nouvelle commande</button></div>{orders.map(o=><div key={o.id} className="tableitem"><div className="row"><div><Link href={`/orders/${o.id}`} className="link" style={{fontWeight:700,fontSize:18}}>{o.project}</Link><div className="muted small">{o.client} · {o.id}</div></div><div className="tagrow"><span className="badge">{o.status}</span><span className="badge">{o.amount}</span></div></div><OrderBar stage={o.stage} /></div>)}</div>}
