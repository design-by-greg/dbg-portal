import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'DBG Portal', description: 'Portail de gestion print Design by Greg' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
