'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
export default function Page(){const r=useRouter(); const [email,setEmail]=useState('contact@designbygreg.fr'); const [password,setPassword]=useState('demo1234'); return <div className="center"><div className="panel auth"><h1>Connexion</h1><div className="muted" style={{marginTop:6}}>Connecte-toi à DBG Portal.</div><div className="form" style={{marginTop:20}}><input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" /><input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mot de passe" /><button className="btn dark" onClick={()=>r.push('/')}>Se connecter</button></div></div></div>}
